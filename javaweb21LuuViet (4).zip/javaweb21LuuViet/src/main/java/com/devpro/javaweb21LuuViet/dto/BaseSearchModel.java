package com.devpro.javaweb21LuuViet.dto;

public abstract class BaseSearchModel {
	Integer Page;

	public Integer getPage() {
		return Page;
	}

	public void setPage(Integer page) {
		Page = page;
	}
	
}
