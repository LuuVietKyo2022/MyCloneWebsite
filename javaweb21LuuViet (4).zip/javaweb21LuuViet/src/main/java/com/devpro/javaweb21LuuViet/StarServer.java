package com.devpro.javaweb21LuuViet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarServer {
	public static void main(String[] args) {
		SpringApplication.run(StarServer.class, args);
	}
}
