function Hien(id){
    var obj=document.getElementById(id);
    obj.style.display="block";
}
function An(id){
    var obj=document.getElementById(id);
    obj.style.display="none";
}